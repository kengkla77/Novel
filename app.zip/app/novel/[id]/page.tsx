import { PrismaClient } from '@prisma/client'
import Link from 'next/link'
import { notFound } from 'next/navigation'

const prisma = new PrismaClient()

async function getNovel(id: string) {
  const novel = await prisma.novel.findUnique({
    where: { id: Number(id) },
    include: {
      chapters: {
        orderBy: { order: 'asc' },
      },
    },
  })
  return novel
}

// ✅ Type ที่ถูกต้องสำหรับ Next.js 16
type Props = {
  params: Promise<{ id: string }>
}

export default async function NovelDetail(props: Props) {
  // ✅ ต้อง await params ออกมาก่อน (สำคัญมาก!)
  const params = await props.params;
  const id = params.id;

  const novel = await getNovel(id)

  if (!novel) {
    notFound()
  }

  return (
    <div className="max-w-3xl mx-auto p-6">
      <Link href="/" className="text-sm text-gray-500 hover:underline mb-4 block">
        ← กลับหน้าแรก
      </Link>

      <div className="bg-white rounded-lg shadow-sm p-6 border">
        <h1 className="text-3xl font-bold mb-2">{novel.title}</h1>
        <p className="text-gray-500 text-sm mb-6">
            อัปเดตล่าสุด: {new Date(novel.updatedAt).toLocaleDateString('th-TH')}
        </p>

        <h3 className="font-semibold text-lg border-b pb-2 mb-3">เรื่องย่อ</h3>
        <p className="text-gray-700 whitespace-pre-wrap mb-8 leading-relaxed">
          {novel.description}
        </p>

        <h3 className="font-semibold text-lg border-b pb-2 mb-3">สารบัญตอน ({novel.chapters.length})</h3>
        
        {novel.chapters.length === 0 ? (
          <p className="text-gray-400 italic">ยังไม่มีตอนใหม่เร็วๆ นี้</p>
        ) : (
          <ul className="space-y-2">
            {novel.chapters.map((chapter) => (
              <li key={chapter.id}>
                <Link 
                  href={`/novel/${novel.id}/chapter/${chapter.id}`}
                  className="block p-3 rounded hover:bg-blue-50 hover:text-blue-600 transition border border-transparent hover:border-blue-100"
                >
                  <span className="font-bold mr-2">ตอนที่ {chapter.order}</span> 
                  {chapter.title}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}