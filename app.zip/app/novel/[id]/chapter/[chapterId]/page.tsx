import { PrismaClient } from '@prisma/client'
import Link from 'next/link'
import { notFound } from 'next/navigation'

const prisma = new PrismaClient()

async function getChapter(chapterId: string) {
  return await prisma.chapter.findUnique({
    where: { id: Number(chapterId) },
    include: { novel: true } 
  })
}

// ✅ Type สำหรับ Next.js 15/16
type Props = {
  params: Promise<{ id: string; chapterId: string }>
}

export default async function ChapterPage(props: Props) {
  // ✅ Await params ก่อนเสมอ
  const params = await props.params;
  const { id, chapterId } = params;

  const chapter = await getChapter(chapterId)

  if (!chapter) notFound()

  return (
    <div className="min-h-screen bg-[#f9f9f9] py-10">
      <div className="max-w-2xl mx-auto bg-white p-8 shadow-sm rounded-lg">
        
        <div className="flex justify-between items-center text-sm text-gray-500 mb-8 border-b pb-4">
          <Link href={`/novel/${id}`} className="hover:text-blue-600">
             ← สารบัญเรื่อง: {chapter.novel.title}
          </Link>
          <span>ตอนที่ {chapter.order}</span>
        </div>

        <h1 className="text-2xl font-bold text-center mb-10">{chapter.title}</h1>

        <div className="prose prose-lg max-w-none text-gray-800 leading-8 whitespace-pre-wrap font-sarabun">
          {chapter.content}
        </div>

        <div className="mt-12 flex justify-center border-t pt-8">
           <Link 
             href={`/novel/${id}`}
             className="px-6 py-2 bg-gray-100 rounded hover:bg-gray-200 transition"
           >
             กลับไปหน้าสารบัญ
           </Link>
        </div>

      </div>
    </div>
  )
}