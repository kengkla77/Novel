import { PrismaClient } from '@prisma/client'
import Link from 'next/link'
// เรียกใช้ Prisma Client
const prisma = new PrismaClient()

// ดึงข้อมูลนิยายทั้งหมด
async function getNovels() {
  const novels = await prisma.novel.findMany({
    orderBy: { createdAt: 'desc' } // เรียงจากใหม่ไปเก่า
  })
  return novels
}

export default async function Home() {
  const novels = await getNovels()

  return (
    <main className="min-h-screen p-8 bg-gray-50">
      <h1 className="text-3xl font-bold mb-6 text-center">📚 เว็บอ่านนิยายของฉัน</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {novels.map((novel) => (
          <div key={novel.id} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition">
            <h2 className="text-xl font-semibold mb-2">{novel.title}</h2>
            <p className="text-gray-600 line-clamp-3">
              {novel.description || "ไม่มีคำอธิบาย"}
            </p>
            <div className="mt-4">
              <Link
                href={`/novel/${novel.id}`}
                className="inline-block bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700 transition"
              >
                อ่านเลย
              </Link>
            </div>
          </div>
        ))}
      </div>

      {novels.length === 0 && (
        <p className="text-center text-gray-500">ยังไม่มีนิยายในระบบ (ลองไปเพิ่มใน Prisma Studio ดูสิ)</p>
      )}
    </main>
  )
}